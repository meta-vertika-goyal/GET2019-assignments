package com.metacube.get2019.facade;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.metacube.get2019.dao.LibraryDao;
import com.metacube.get2019.factory.LibraryFactory;
import com.metacube.get2019.model.Book;


/**
 * @author Vertika
 */
public class LibraryFacade {
	static LibraryDao library=LibraryFactory.getInstanceOfLibraryDao();
	private static final String QUERY_GET_BOOKS="select * from book";
	private static final String QUERY_GET_BOOK_BY_TITLE="select * from book where title = ?";
	private static final String QUERY_DELETE_BOOKS="delete from book";
	private static final String QUERY_DELETE_BOOK_BY_ID="delete from book where id = ?";
	private static final String QUERY_POST_BOOK="insert into book(title,writer,publisher,publishedYear) values(?,?,?,?)";
	private static final String QUERY_PUT_BOOK="update book set writer=?,publisher=? where title=? and publishedyear=?";
	
	/**
	 * This method is used to retrieve all books.
	 * @return json string of the retrieved books
	 * @throws SQLException
	 */
	public static String getBooks() throws SQLException{
		List<Book> fruitList=library.getAllBooks(QUERY_GET_BOOKS);
		if(fruitList.size() > 0)
		{
			Gson gson = new Gson();
			String inventoryJson = gson.toJson(fruitList);
			return inventoryJson;
		}
		else
		{
			return "No Library Found" ;
		}
	}
		
	/**
	 * This method is used to Retrieve book by title
	 * @param bookTitle is the title of the book to be retrieved 
	 * @return json string of the retrieved book
	 * @throws SQLException
	 */
	public static String getBookByTitle(String bookTitle) throws SQLException{
		Book book=library.getBookByTitle(QUERY_GET_BOOK_BY_TITLE,bookTitle);
		if( book.getTitle() != null )
		{
			Gson gson = new Gson();
			String libraryJson = gson.toJson(book);
			return libraryJson;
		}
		else
		{
			return "No Book Found";
		}
		
	}

	/**
	 * This method is used to Delete all books
	 * @return text if the deletion has been performed successfully
	 */
	public static String deleteLibrary() {
		boolean deleted=library.deleteAllBooks(QUERY_DELETE_BOOKS);
		if(deleted){
			return "Successfully deleted";
		}
		else{
		return "Error in deletion...";
		}
	}

	/**
	 * This method is used to delete book by Id
	 * @param bookId is the book id of the book to be deleted
	 * @return text if the deletion has been performed successfully
	 * @throws SQLException
	 */
	public static String deleteBookById(int bookId) {
		
		boolean deleted=library.deleteBookById(QUERY_DELETE_BOOK_BY_ID,bookId);
		if(deleted){
			return "Successfully deleted";
		}
		else{
		return "Error in deletion...";
		}
		
	}

	/**
	 * This method is used to create a new book record
	 * @param jsonString is the input json 
	 * @return text if the insertion has been performed successfully
	 */
	public static String postBook(String jsonString) {
		Gson gson = new Gson();
		TypeToken<Book> token = new TypeToken<Book>() {};
		Book book = gson.fromJson(jsonString, token.getType());
		boolean inserted=library.postBook(QUERY_POST_BOOK,book);
		if(inserted)
			return "Successfully inserted";
		else{
			return "Error in insertion....";
		}
		
	}

	/**
	 * This method is used to Update book by title and published year
	 * @param jsonString is the input json in the body of the put request
	 * @return text if the updation has been performed successfully
	 */
	public static String updateBook(String jsonString) {
		Gson gson = new Gson();
		TypeToken<Book> token = new TypeToken<Book>() {};
		Book book = gson.fromJson(jsonString, token.getType());
		boolean inserted=library.updateBook(QUERY_PUT_BOOK,book);
		if(inserted)
			return "Successfully updated";
		else{
			return "Error in updation....";
		}
	}
}
