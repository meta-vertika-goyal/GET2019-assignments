package com.metacube.get2019.factory;

import com.metacube.get2019.dao.LibraryDao;
import com.metacube.get2019.model.Book;

public class LibraryFactory {
	public static Book getInstanceOfBook()
	{
		return new Book();
		
	}
	public static LibraryDao getInstanceOfLibraryDao()
	{
		return new LibraryDao();
		
	}

}
