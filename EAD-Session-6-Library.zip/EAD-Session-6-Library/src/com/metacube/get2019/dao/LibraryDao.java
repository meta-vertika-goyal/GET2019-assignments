package com.metacube.get2019.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.metacube.get2019.factory.LibraryFactory;
import com.metacube.get2019.model.Book;
/**
 * @author Vertika
 */
public class LibraryDao implements BaseDao {

	
	@Override
	public Book getBookByTitle(String query, String bookTitle) {
			try{
				Connection connection=DatabaseConnection.connect();
				PreparedStatement preparedStatement=connection.prepareStatement(query);
				preparedStatement.setString(1,bookTitle);
				ResultSet rs= preparedStatement.executeQuery();
				Book book;
				book=LibraryFactory.getInstanceOfBook();
				while(rs.next())
				{
					book=LibraryFactory.getInstanceOfBook();
					book.setId(rs.getInt("id"));
					book.setTitle(rs.getString("title"));
					book.setWriter(rs.getString("writer"));
					book.setPublisher(rs.getString("publisher"));
					book.setPublishedYear(rs.getInt("publishedyear"));
				}
				return book;
		}
				catch(Exception e){
					e.printStackTrace();
				}
				return null;
	}

	@Override
	public boolean deleteAllBooks(String query) {
		try{
			Connection connection=DatabaseConnection.connect();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			int rowsAffected= preparedStatement.executeUpdate();
			if( rowsAffected > 0){
				return true;
			}
		}
			catch(Exception e){
				e.printStackTrace();
			}
			return false;
	}

	@Override
	public boolean deleteBookById(String query, int bookId) {
		
		try{
			Connection connection=DatabaseConnection.connect();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1,bookId);
			int rowsAffected= preparedStatement.executeUpdate();
			if( rowsAffected >0){
				return true;
			}
		}
			catch(Exception e){
				e.printStackTrace();
			}
			return false;
	}
	
	@Override
	public List<Book> getAllBooks(String query) {
		try{
			Connection connection=DatabaseConnection.connect();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			ResultSet rs= preparedStatement.executeQuery();
			List<Book> bookList=new ArrayList<Book>();
			Book book;
			while(rs.next())
			{
				book=LibraryFactory.getInstanceOfBook();
				book.setId(rs.getInt("id"));
				book.setTitle(rs.getString("title"));
				book.setWriter(rs.getString("writer"));
				book.setPublisher(rs.getString("publisher"));
				book.setPublishedYear(rs.getInt("publishedyear"));
				bookList.add(book);
			}
			return bookList;
	}
			catch(Exception e){
				e.printStackTrace();
			}
			return null;
	}

	public boolean postBook(String query,Book book) {
		try{
			Connection connection=DatabaseConnection.connect();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1,book.getTitle());
			preparedStatement.setString(2,book.getWriter());
			preparedStatement.setString(3,book.getPublisher());
			preparedStatement.setInt(4,book.getPublishedYear());
			int rowsAffected= preparedStatement.executeUpdate();
			
			if(rowsAffected>0){
				return true;
			}
			else{
				return false;
			}
	}
			catch(Exception e){
				e.printStackTrace();
			}
			return false;
	}
   @Override
	public boolean updateBook(String query, Book book) {
		try{
			Connection connection=DatabaseConnection.connect();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(3,book.getTitle());
			preparedStatement.setString(1,book.getWriter());
			preparedStatement.setString(2,book.getPublisher());
			preparedStatement.setInt(4,book.getPublishedYear());
			int rowsAffected= preparedStatement.executeUpdate();
			
			if(rowsAffected>0){
				return true;
			}
			else{
				return false;
			}
	}
			catch(Exception e){
				e.printStackTrace();
			}
			return false;
	}

}
