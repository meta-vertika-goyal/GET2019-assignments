/*
 * It is a method to validate all the fields of the Registration form
 * @return testing boolean
 */
function validateForm() {
    var r1 = validateFirstName();
    var r2 = validateLastName();
    var r3 = validateFatherName();
    var isValidate = r1 && r2 && r3;
    return isValidate;
}

function validateFatherName(){
	var x = document.getElementById("father_name_validation").value;
	var expression = /^[a-zA-Z ]*$/;
	var result = expression.test(x) ;
	if( result === true && document.getElementById("father_name_validation").value.length > 2 ) {
		return true;
	} else {
		document.getElementById("father_name_validation").innerHTML="The entered name is not valid";
	    return false;
	}
}

function validateFirstName(){
	var x = document.getElementById("first_name_validation").value;
	var expression = /^[a-zA-Z ]*$/;
	var result = expression.test(x) ;
	if( result === true && document.getElementById("first_name_validation").value.length > 2 ) {
		return true;
	} else {
		document.getElementById("first_name_validation").innerHTML="The entered name is not valid";
	    return false;
	}
}

function validateLastName(){
	var x = document.getElementById("last_name_validation").value;
	var expression = /^[a-zA-Z ]*$/;
	var result = expression.test(x) ;
	if( result === true && document.getElementById("last_name_validation").value.length > 2 ) {
		return true;
	} else {
		document.getElementById("last_name_validation").innerHTML="The entered name is not valid";
	    return false;
	}
}