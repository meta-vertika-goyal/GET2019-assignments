package com.metacube.get2019;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class EditProfileServlet
 */
@WebServlet("/EditProfileServlet")
public class EditProfileServlet extends HttpServlet {
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  
		int employee_id = Integer.parseInt(request.getParameter("employee_id"));
		
			
			String full_name = request.getParameter("full_name");
			String gender = request.getParameter("gender");
			long contact = Long.parseLong(request.getParameter("contact"));
			String organization = request.getParameter("organization");
			
			// Page for updating the data in the database
			out.print("<!DOCTYPE html>"
						+ "<HTML> "
						+ "<HEAD> "
						+ "<TITLE>Edit Employee Details</TITLE>"
						+ "</HEAD> "
						+ "<BODY> "
						+ "<div align=center name='UpdateStudentForm'>"
						+ "<form action ='updateStudent' method = 'get'>"
						+ "<H1>Here's your current profile "+full_name+"!</H1>"
						+ "<table cellspacing=10>"
						+ "<tr >"         
						+ "<td><label style=color:red>*</label><label >Employee ID :</label></td>" 
						+ "<td><input  type=text name = 'employee_id' required value = '"+employee_id+"' readonly></td>"
						+ "</tr>"
						+ "<tr >"         
						+ "<td><label style=color:red>*</label><label >Full Name :</label></td>" 
						+ "<td><input  type=text name = 'full_name' required value = '"+full_name+"'></td>"
						+ "</tr>"
						+ "<td id = 'first_name_validation' style=color:red colspan=2></td></tr>"
						+ "<tr >"        
						+ "<td><label style=color:red>*</label><label >Last Name :</label></td>" 
						+ "<td><input  type=text name = 'last_name' required value = '"+last_name+"'></td>"
						+ "</tr>"
						+ "<td id = 'last_name_validation' style=color:red colspan=2></td></tr>"
						+ "<tr >"
						+ "<td><label style=color:red>*</label><label >Father's Name :</label></td>"
						+ "<td><input  id = 'fnm' type=text name = 'father_name' required value = '"+father_name+"'></td>"
						+ "</tr>"
						+ "<td id = 'father_name_validation' style=color:red colspan=2></td></tr>"
						+ "<tr >"      
						+ "<td><label style=color:red>*</label><label >Age :</label></td>"
						+ "<td><input  type=number name = 'age' required value = '"+age+"'></td>"
						+ "</tr>"
						+ "<td id = 'age_validation' style=color:red colspan=2></td></tr>"
						+ "<tr>"
						+ "<td><label style=color:red>*</label><label >Class :</label></td>"
						+ "<td><input type='text' name = 'class' required value = '"+class_name+"'></td>"
						+ "</tr>"
						+ "<tr>"
						+ "<td><label style=color:red>*</label><label >Email name :</label></td>" 
						+ "<td><input type='text' name = 'email' required value = '"+email+"'></td>"
						+ "</tr>"
						+ "<td id = 'email_validation' style=color:red colspan=2></td></tr>"
						+ "</table>"
						+ "<br/>"
						+ "<input type = 'submit' value = 'Update'></a>"
						+ "</form> "
						+ "</div>"
						+ "</BODY>"
						+ "</HTML>");
		
		
	}

	}
	}

	


