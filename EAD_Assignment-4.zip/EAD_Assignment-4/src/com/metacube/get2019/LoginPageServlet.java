package com.metacube.get2019;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginPageServlet
 */
@WebServlet("/LoginPageServlet")
public class LoginPageServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  
		String email_id = request.getParameter("home_email_id");  
		String password = request.getParameter("home_password"); 
		try{  
			DatabaseConnection jdbcObj = new DatabaseConnection();
			Connection con = jdbcObj.connect();
			Statement st = con.createStatement(); 
			boolean found = st.execute(Queries.searchEmployeeQuery(email_id, password));
			if ( found ) {
				 RequestDispatcher rd=request.getRequestDispatcher("UserPage.html");  
			} else {
				out.print("Sorry UserName or Password Error!");  
			    //RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
			    //rd.include(request, response);
			}
		} catch ( SQLIntegrityConstraintViolationException e ) {
			e.printStackTrace();
		}
		catch ( Exception e2 ) {
			e2.printStackTrace();
		} finally {
			out.close();
		}  
	} 
}
		
