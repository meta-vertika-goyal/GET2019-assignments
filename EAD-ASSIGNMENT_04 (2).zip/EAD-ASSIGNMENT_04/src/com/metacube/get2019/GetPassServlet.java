package com.metacube.get2019;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetPassServlet
 */
@WebServlet("/GetPassServlet")
public class GetPassServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();  
			String currency=request.getParameter("currency");
			String vehicle_number=request.getParameter("signed_vehicle_number");
			int employee_id = Integer.parseInt(request.getParameter("signed_emp_id"));
			float price = Float.parseFloat(request.getParameter("pass"));
			
			try{  
				DatabaseConnection jdbcObj = new DatabaseConnection();
				Connection con = jdbcObj.connect();
				Statement st = con.createStatement();
				
				st.executeUpdate(Queries.addPassQuery(vehicle_number,price,employee_id));
		} catch ( SQLIntegrityConstraintViolationException e ) {
			RequestDispatcher rd=request.getRequestDispatcher("VehicleRegistrationForm.html");  
		    rd.include(request, response);
		    out.print("<div ALIGN=CENTER style='background-color:midnightblue;width:40%;height:100%;margin-top:-2em;color:white;'>This vehicle already exists!</div>");
			e.printStackTrace();
		}
		catch ( Exception e2 ) {
			e2.printStackTrace();
		} finally {
			out.close();
		}  
	} 
		
}
