import { Component, OnInit, Input } from '@angular/core';
import { Task } from '../task';
import { NgForm } from '@angular/forms';
import { TaskService } from '../task.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {
 
  @Input() public task:Task;
  validTask:boolean;
  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
    console.log(this.task);
  }
  editTask(editTaskForm: NgForm){
  
    TaskService.taskList.splice(TaskService.taskList.indexOf(editTaskForm.value), 1,editTaskForm.value);
    this.activeModal.close();
      }
  checkValid(){
    if(this.task.create_date>this.task.complete_date)
  {
    this.validTask=false;
  
  }
  else{
    this.validTask=true;
  }
   return this.validTask;
    }
}
