import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { Task } from '../task';
import { NgForm } from '@angular/forms';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-create-modal-content',
  templateUrl: './create-modal-content.component.html',
  styleUrls: ['./create-modal-content.component.css']
})
export class CreateModalContentComponent implements OnInit {
   task:Task=new Task("","","","","","");
  validTask:boolean=true;
  newtaskForm: NgForm;
  constructor(public activeModal: NgbActiveModal,public taskService:TaskService) {}

  ngOnInit() {
    console.log(this.task.title);
  }
  onSubmit(newtaskForm: NgForm){
    this.newtaskForm=newtaskForm;
    TaskService.taskList.push(newtaskForm.value);
    this.activeModal.close(); 
  }
checkValid(){
  if(this.task.create_date>this.task.complete_date)
{
  this.validTask=false;

}
else{
  this.validTask=true;
}
 return this.validTask;
  }

}
