import { Component, OnInit, Input } from '@angular/core';
import { CreateModalContentComponent } from '../create-modal-content/create-modal-content.component';
import { TaskService } from '../task.service';
import { Task } from '../task';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EditTaskComponent } from '../edit-task/edit-task.component';

@Component({
  selector: 'app-my-tasks',
  templateUrl: './my-tasks.component.html',
  styleUrls: ['./my-tasks.component.css']
})
export class MyTasksComponent implements OnInit {
  taskList:any[];
  constructor(public taskService:TaskService,private modalService: NgbModal) { 
  }

  ngOnInit() {
    this.taskList=TaskService.taskList;
  }
  deleteTask(task:Task){
    TaskService.taskList.splice(TaskService.taskList.indexOf(task), 1);
  }
  editTask(task:Task){
    const modalRef = this.modalService.open(EditTaskComponent);
    modalRef.componentInstance.task=task;
  }


}
