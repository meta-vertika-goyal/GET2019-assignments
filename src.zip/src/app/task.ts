export class Task {
    constructor(public title:string,
        public description:string,
        public  status:string,
        public create_date:string,
        public complete_date:string,
        public priority:string){}
}
