import { Component, OnInit } from '@angular/core';
import { CreateModalContentComponent } from '../create-modal-content/create-modal-content.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-my-task-tracker',
  templateUrl: './my-task-tracker.component.html',
  styleUrls: ['./my-task-tracker.component.css']
})
export class MyTaskTrackerComponent implements OnInit {

  constructor(private modalService: NgbModal) { }
  open(){
    const modalRef = this.modalService.open(CreateModalContentComponent);
  }


  ngOnInit() {
  }

}
